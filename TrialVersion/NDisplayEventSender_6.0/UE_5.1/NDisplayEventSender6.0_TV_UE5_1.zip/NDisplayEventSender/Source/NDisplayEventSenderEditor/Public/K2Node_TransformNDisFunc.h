﻿// Copyright Ye RongZhen(MapleLeaf_Ye) 2024


#pragma once

#include "CoreMinimal.h"
#include "K2Node.h"
#include "K2Node_AddPinInterface.h"
#include "K2Node_TransformNDisFunc.generated.h"

UCLASS()
class NDISPLAYEVENTSENDEREDITOR_API UK2Node_TransformNDisFunc : public UK2Node,public IK2Node_AddPinInterface
{
	GENERATED_BODY()
	//UEdGraphNode Interface
	virtual FText GetTooltipText() const override;
	virtual FText GetNodeTitle(ENodeTitleType::Type TitleType) const override;
	//End

	//UK2Node Interface
	virtual FText GetMenuCategory() const override;
	virtual void GetMenuActions(FBlueprintActionDatabaseRegistrar& ActionRegistrar) const override;
	virtual void GetNodeContextMenuActions(UToolMenu* Menu, UGraphNodeContextMenuContext* Context) const override;
	//End

	virtual void AllocateDefaultPins() override;
	virtual void ExpandNode(FKismetCompilerContext& CompilerContext, UEdGraph* SourceGraph) override;
	virtual void PostReconstructNode() override;
	virtual void NotifyPinConnectionListChanged(UEdGraphPin* Pin) override;

	virtual void AddInputPin() override;
	virtual void RemoveInputPin(UEdGraphPin* Pin) override;
	virtual bool CanRemovePin(const UEdGraphPin* Pin) const { return true; };


	virtual FLinearColor GetNodeTitleColor() const
	{
		return FColor::Red;
	}
	virtual FLinearColor GetNodeBodyTintColor() const
	{
		return FColor::Yellow;
	}

	virtual TSharedPtr<SWidget> CreateNodeImage() const override;

	virtual bool ShowPaletteIconOnNode() const { return true; }

	FSlateIcon GetIconAndTint(FLinearColor& OutColor) const override;

	void SyncPinNames();
	UPROPERTY()
	TArray<FName> FunParamPins;
	UPROPERTY()
	int32 PinNum = 0;
	
};
