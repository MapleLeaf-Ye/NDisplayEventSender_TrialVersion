﻿// Copyright Ye RongZhen(MapleLeaf_Ye) 2024


#include "K2Node_TransformNDisFunc.h"

#include "BlueprintActionDatabaseRegistrar.h"
#include "BlueprintNodeSpawner.h"
#include "K2Node_CallFunction.h"
#include "K2Node_MakeArray.h"
#include "KismetCompiler.h"
#include "Kismet2/BlueprintEditorUtils.h"
#include "NDisplayEventSender/Public/BL_NDisplayEventSender.h"
#include "NDisplayEventNodeSlateStyle.h"

const static FString TipStr = TEXT("Use this Change normal function to NDisplay event function. \n")
	TEXT("用于多节点事件分发，只需要为其指定函数的参数，就可以在主节点上将事件分发并执行在各个结点上，注意这个节点必须被放置在自定义事件或者函数的第一个\n")
	TEXT("支持函数和事件的转换，但尽量保证转换节点放置在第一个，否则转换节点前面的逻辑可能会被执行多次\n")
	TEXT("注意：\n")
	TEXT("1.可以使用普通函数或者事件去调用被转换后的函数或事件，且可以连续调用，但是不要多时间内调用同一个被转换后的函数或者事件（名字相同的）多次，否则可能只能执行一次\n")
	TEXT("2.正在转换的函数或者事件内部请不要去调用其他已转换的事件或者函数，否则可能会导致执行顺序混乱且多次执行\n")
	TEXT("3.转换事件尽量写在每个节点都会存在的对象上（因为转换节点需要通过该对象寻找函数，如果写在一个非各个结点都存在的对象上会导致那个节点无法执行目标函数）\n")
	TEXT("4.尽量只用ExecuteMultiNodeEvent_Auto节点，如果非要使用ExecuteMultiNodeEvent那么每个节点需要执行的逻辑请写在NormalExe引脚，如果需要主机特例执行逻辑则写在MultiNodeExe（因为该引脚是主机分发事件执行前执行的，其它节点不执行该引脚的逻辑）\n")
	TEXT("5.转换函数或事件的参数顺序必须一对一，例如：函数参数一必须对应转换节点参数一，函数参数二必须对应转换节点参数二");

FText UK2Node_TransformNDisFunc::GetTooltipText() const
{
	return FText::FromString(TipStr);
}

FText UK2Node_TransformNDisFunc::GetNodeTitle(ENodeTitleType::Type TitleType) const
{
	return FText::FromString(TEXT("ExecuteMultiNodeEvent_Auto"));
}

FText UK2Node_TransformNDisFunc::GetMenuCategory() const
{
	return FText::FromString(TEXT("NDisplayEventSender|EventSenderLibrary"));
}

void UK2Node_TransformNDisFunc::GetMenuActions(FBlueprintActionDatabaseRegistrar& ActionRegistrar) const
{
	Super::GetMenuActions(ActionRegistrar);

	UClass* ActionKey = GetClass();

	if (ActionRegistrar.IsOpenForRegistration((ActionKey)))
	{
		UBlueprintNodeSpawner* Spawner = UBlueprintNodeSpawner::Create(ActionKey);
		check(Spawner);
		ActionRegistrar.AddBlueprintAction(ActionKey,Spawner);
	}
}

void UK2Node_TransformNDisFunc::AllocateDefaultPins()
{
	Super::AllocateDefaultPins();

	CreatePin(EGPD_Input,UEdGraphSchema_K2::PC_Exec,UEdGraphSchema_K2::PN_Execute);
	CreatePin(EGPD_Output,UEdGraphSchema_K2::PC_Exec,UEdGraphSchema_K2::PN_Then);

	for (int i = 0; i < PinNum; i++)
	{
		FString pinName = FString::Printf(TEXT("Param%d"), i);
		UEdGraphPin* pin = CreatePin(EGPD_Input, UEdGraphSchema_K2::PC_Wildcard, *pinName);
		FunParamPins.Add(*pinName);
	}
}

void UK2Node_TransformNDisFunc::GetNodeContextMenuActions(UToolMenu* Menu, UGraphNodeContextMenuContext* Context) const
{
	Super::GetNodeContextMenuActions(Menu, Context);

	static FName CommutativeAssociativeBinaryOperator = FName("K2Node_TransformNDisFunc");
	FText CommutativeAssociativeBinaryOperatorStr = NSLOCTEXT("K2Node_TransformNDisFuncNS","K2Node_TransformNDisFunc","Operator Node");
	if (Context->Pin != nullptr)
	{
		if (CanRemovePin(Context->Pin))
		{
			FToolMenuSection& section = Menu->AddSection(CommutativeAssociativeBinaryOperator,CommutativeAssociativeBinaryOperatorStr);
			section.AddMenuEntry(FName("RemovePin"),NSLOCTEXT("K2Node_TransformNDisFuncNS","RemovePin","Remove Pin"),NSLOCTEXT("K2Node_TransformNDisFuncNS","RemovePinTool","Remove Pin From Node"),FSlateIcon(),
				FUIAction(FExecuteAction::CreateUObject(const_cast<UK2Node_TransformNDisFunc*>(this),&UK2Node_TransformNDisFunc::RemoveInputPin,const_cast<UEdGraphPin*>(Context->Pin))));
		}
	}
}

void UK2Node_TransformNDisFunc::ExpandNode(FKismetCompilerContext& CompilerContext, UEdGraph* SourceGraph)
{
	Super::ExpandNode(CompilerContext, SourceGraph);
#if VERSION_BINARY
	UEdGraphPin* ExePin = GetExecPin();
	UEdGraphPin* ThenPin = GetThenPin();

	if (ExePin && ThenPin)
	{
		FName FunName_TriggleMultiNodeEvent = GET_FUNCTION_NAME_CHECKED(UBL_NDisplayEventSender, K2_TriggleMultiNodeEvent_Binary_Simple);

		UK2Node_CallFunction* TriggleMultiNodeEventNode = CompilerContext.SpawnIntermediateNode<UK2Node_CallFunction>(this, SourceGraph);
		TriggleMultiNodeEventNode->FunctionReference.SetExternalMember(FunName_TriggleMultiNodeEvent, UBL_NDisplayEventSender::StaticClass());
		TriggleMultiNodeEventNode->AllocateDefaultPins();

		UEdGraphPin* FunParamsPin = TriggleMultiNodeEventNode->FindPinChecked(FName("FunParams"), EGPD_Input);
		UEdGraphPin* MuitiOutPin = TriggleMultiNodeEventNode->FindPinChecked(FName("NormalExe"), EGPD_Output);


		CompilerContext.MovePinLinksToIntermediate(*ExePin, *TriggleMultiNodeEventNode->GetExecPin());
		CompilerContext.MovePinLinksToIntermediate(*ThenPin, *MuitiOutPin);

		UK2Node_MakeArray* MakeArrayNode = CompilerContext.SpawnIntermediateNode<UK2Node_MakeArray>(this, SourceGraph);
		MakeArrayNode->AllocateDefaultPins();

		UEdGraphPin* ArrayOut = MakeArrayNode->GetOutputPin();
		ArrayOut->MakeLinkTo(FunParamsPin);
		MakeArrayNode->PinConnectionListChanged(ArrayOut);

		FName FunName_InputParamToMultiNodeFunParam = GET_FUNCTION_NAME_CHECKED(UBL_NDisplayEventSender, InputParamToMultiNodeFunParam);

		for (int32 i = 0; i < PinNum; i++)
		{
			// Make Array node has one input by default
			if (i > 0)
				MakeArrayNode->AddInputPin();

			// find the input pin on the "Make Array" node by index.
			const FString PinName = FString::Printf(TEXT("[%d]"), i);
			UEdGraphPin* ArrayInputPin = MakeArrayNode->FindPinChecked(PinName);

			UEdGraphPin* currentInputPin = FindPinChecked(FString::Printf(TEXT("Param%d"), i), EGPD_Input);

			UK2Node_CallFunction* InputParamToMultiNodeFunParamNode = CompilerContext.SpawnIntermediateNode<UK2Node_CallFunction>(this, SourceGraph);
			InputParamToMultiNodeFunParamNode->FunctionReference.SetExternalMember(FunName_InputParamToMultiNodeFunParam, UBL_NDisplayEventSender::StaticClass());
			InputParamToMultiNodeFunParamNode->AllocateDefaultPins();

			CompilerContext.MovePinLinksToIntermediate(*currentInputPin, *InputParamToMultiNodeFunParamNode->FindPinChecked(TEXT("InParam")));
			InputParamToMultiNodeFunParamNode->FindPinChecked(TEXT("InParam"))->PinType = MoveTemp(currentInputPin->PinType);
			GetGraph()->NotifyGraphChanged();
			InputParamToMultiNodeFunParamNode->FindPinChecked(UEdGraphSchema_K2::PN_ReturnValue)->MakeLinkTo(ArrayInputPin);
		}// end of for
	}
	BreakAllNodeLinks();
#elif VERSION_JSON
	UEdGraphPin* ExePin = GetExecPin();
	UEdGraphPin* ThenPin = GetThenPin();

	if (ExePin && ThenPin)
	{
		FName FunName_TriggleMultiNodeEvent = GET_FUNCTION_NAME_CHECKED(UBL_NDisplayEventSender, K2_TriggleMultiNodeEvent_Simple);

		UK2Node_CallFunction* TriggleMultiNodeEventNode = CompilerContext.SpawnIntermediateNode<UK2Node_CallFunction>(this, SourceGraph);
		TriggleMultiNodeEventNode->FunctionReference.SetExternalMember(FunName_TriggleMultiNodeEvent, UBL_NDisplayEventSender::StaticClass());
		TriggleMultiNodeEventNode->AllocateDefaultPins();

		UEdGraphPin* FunParamsPin = TriggleMultiNodeEventNode->FindPinChecked(FName("FunParams"), EGPD_Input);
		UEdGraphPin* MuitiOutPin = TriggleMultiNodeEventNode->FindPinChecked(FName("NormalExe"), EGPD_Output);


		CompilerContext.MovePinLinksToIntermediate(*ExePin, *TriggleMultiNodeEventNode->GetExecPin());
		CompilerContext.MovePinLinksToIntermediate(*ThenPin, *MuitiOutPin);

		UK2Node_MakeArray* MakeArrayNode = CompilerContext.SpawnIntermediateNode<UK2Node_MakeArray>(this, SourceGraph);
		MakeArrayNode->AllocateDefaultPins();

		UEdGraphPin* ArrayOut = MakeArrayNode->GetOutputPin();
		ArrayOut->MakeLinkTo(FunParamsPin);
		MakeArrayNode->PinConnectionListChanged(ArrayOut);

		FName FunName_InputParamToString = GET_FUNCTION_NAME_CHECKED(UBL_NDisplayEventSender, InputParamToString);

		for (int32 i = 0; i < PinNum; i++)
		{
			// Make Array node has one input by default
			if (i > 0)
				MakeArrayNode->AddInputPin();

			// find the input pin on the "Make Array" node by index.
			const FString PinName = FString::Printf(TEXT("[%d]"), i);
			UEdGraphPin* ArrayInputPin = MakeArrayNode->FindPinChecked(PinName);

			UEdGraphPin* currentInputPin = FindPinChecked(FString::Printf(TEXT("Param%d"), i), EGPD_Input);

			UK2Node_CallFunction* InputParamToStringNode = CompilerContext.SpawnIntermediateNode<UK2Node_CallFunction>(this, SourceGraph);
			InputParamToStringNode->FunctionReference.SetExternalMember(FunName_InputParamToString, UBL_NDisplayEventSender::StaticClass());
			InputParamToStringNode->AllocateDefaultPins();

			CompilerContext.MovePinLinksToIntermediate(*currentInputPin, *InputParamToStringNode->FindPinChecked(TEXT("InParam")));
			InputParamToStringNode->FindPinChecked(TEXT("InParam"))->PinType = MoveTemp(currentInputPin->PinType);
			GetGraph()->NotifyGraphChanged();
			InputParamToStringNode->FindPinChecked(UEdGraphSchema_K2::PN_ReturnValue)->MakeLinkTo(ArrayInputPin);
		}// end of for
	}
	BreakAllNodeLinks();
#else
	BreakAllNodeLinks();
	COMPILE_ERROR(Error);
#endif
}

void UK2Node_TransformNDisFunc::AddInputPin()
{
	FString pinName = FString::Printf(TEXT("Param%d"),PinNum);
	UEdGraphPin* pin = CreatePin(EGPD_Input,UEdGraphSchema_K2::PC_Wildcard,*pinName);
	FunParamPins.Add(*pinName);
	PinNum++;
}

void UK2Node_TransformNDisFunc::RemoveInputPin(UEdGraphPin* Pin)
{
	check(Pin->Direction == EGPD_Input);
	check(Pin->ParentPin == nullptr);
	checkSlow(Pins.Contains(Pin));
	FScopedTransaction Transaction(FText::FromString("MyK2Node_RemovePin"));
	Modify();

	TFunction<void(UEdGraphPin*)> RemovePinLambda = [this, &RemovePinLambda](UEdGraphPin* PinToRemove)
	{
		for (int32 SubPinIndex = PinToRemove->SubPins.Num()-1; SubPinIndex >= 0; --SubPinIndex)
		{
			RemovePinLambda(PinToRemove->SubPins[SubPinIndex]);
		}

		int32 PinRemovalIndex = INDEX_NONE;
		if (Pins.Find(PinToRemove, PinRemovalIndex))
		{
			FunParamPins.Remove(*PinToRemove->GetName());
			Pins.RemoveAt(PinRemovalIndex);
			PinToRemove->MarkAsGarbage();
		}
	};

	RemovePinLambda(Pin);
	PinConnectionListChanged(Pin);
	
	PinNum--;
	//RemovePin(Pin);
	SyncPinNames();
	FBlueprintEditorUtils::MarkBlueprintAsStructurallyModified(GetBlueprint());
}

TSharedPtr<SWidget> UK2Node_TransformNDisFunc::CreateNodeImage() const
{
	return SNew(SImage).ColorAndOpacity(FColor::White).Image(FNDisplayEventNodeSlateStyle::Get().GetBrush(TEXT("FunIcon")));
}

FSlateIcon UK2Node_TransformNDisFunc::GetIconAndTint(FLinearColor& OutColor) const
{
	static const FSlateIcon Icon = FSlateIcon("NDisplayEventNodeSlateStyle", "FunIcon");
	return Icon;
}

void UK2Node_TransformNDisFunc::SyncPinNames()
{
	FunParamPins.Empty();
	int32 CurrentNumParentPins = 0;
	for (int32 PinIndex = 0; PinIndex < Pins.Num(); ++PinIndex)
	{
		UEdGraphPin*& CurrentPin = Pins[PinIndex];
		if (CurrentPin->Direction == EGPD_Input &&
			CurrentPin->ParentPin == nullptr && CurrentPin->PinType.PinCategory != UEdGraphSchema_K2::PC_Exec)
		{
			const FName OldName = CurrentPin->PinName;
			const FName ElementName = *FString::Printf(TEXT("Param%d"),CurrentNumParentPins++);
			FunParamPins.Add(ElementName);
			CurrentPin->Modify();
			CurrentPin->PinName = ElementName;

			if (CurrentPin->SubPins.Num() > 0)
			{
				const FString OldNameStr = OldName.ToString();
				const FString ElementNameStr = ElementName.ToString();
				FString OldFriendlyName = OldNameStr;
				FString ElementFriendlyName = ElementNameStr;

				// SubPin Friendly Name has an extra space in it so we need to account for that
				OldFriendlyName.InsertAt(1, " ");
				ElementFriendlyName.InsertAt(1, " ");

				for (UEdGraphPin* SubPin : CurrentPin->SubPins)
				{
					FString SubPinFriendlyName = SubPin->PinFriendlyName.ToString();
					SubPinFriendlyName.ReplaceInline(*OldFriendlyName, *ElementFriendlyName);

					SubPin->Modify();
					SubPin->PinName = *SubPin->PinName.ToString().Replace(*OldNameStr, *ElementNameStr);
					SubPin->PinFriendlyName = FText::FromString(SubPinFriendlyName);
				}
			}
		}
	}
}

void UK2Node_TransformNDisFunc::PostReconstructNode()
{
	Super::PostReconstructNode();

	for (int32 i = 0; i< PinNum; i++)
	{
		NotifyPinConnectionListChanged(FindPinChecked(FunParamPins[i],EGPD_Input));
	}
}

void UK2Node_TransformNDisFunc::NotifyPinConnectionListChanged(UEdGraphPin* Pin)
{
	Super::NotifyPinConnectionListChanged(Pin);
	if (Pin->PinType.PinCategory == UEdGraphSchema_K2::PC_Exec || Pin->Direction == EGPD_Output)
	{
		return;
	}

	if (Pin->LinkedTo.Num() > 0)
	{
		UEdGraphPin* LinkPin = Pin->LinkedTo[0];
		if (Pin->PinType != LinkPin->PinType)
		{
			Pin->PinType = MoveTemp(LinkPin->PinType);
			GetGraph()->NotifyGraphChanged();
		}
	}
	else if(Pin->PinType.PinCategory != UEdGraphSchema_K2::PC_Wildcard)
	{
		Pin->ResetDefaultValue();
		Pin->PinType.PinCategory = UEdGraphSchema_K2::PC_Wildcard;
		GetGraph()->NotifyGraphChanged();
	}
}
