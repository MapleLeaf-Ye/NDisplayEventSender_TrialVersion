// Copyright Ye RongZhen(MapleLeaf_Ye) 2024


#include "NDisplayEventSenderEditor.h"
#include "NDisplayEventNodeSlateStyle.h"

#define LOCTEXT_NAMESPACE "FNDisplayEventSenderEditorModule"


void FNDisplayEventSenderEditorModule::StartupModule()
{
	FNDisplayEventNodeSlateStyle::Initialize();
	FNDisplayEventNodeSlateStyle::ReloadTextures();
}

void FNDisplayEventSenderEditorModule::ShutdownModule()
{
	FNDisplayEventNodeSlateStyle::Shutdown();
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FNDisplayEventSenderEditorModule, NDisplayEventSenderEditor)