﻿// Copyright Ye RongZhen(MapleLeaf_Ye) 2024


#pragma once

#include "CoreMinimal.h"
#include "Subsystems/WorldSubsystem.h"
#include "NDisplayEventSubsystem.generated.h"


UCLASS()
class UNDisplayEventSubsystem : public UWorldSubsystem
{
	GENERATED_BODY()
public:
	UFUNCTION()
	ANDisplayEventManager* GetMultiEventManager();
	
protected:
	virtual void OnWorldBeginPlay(UWorld& InWorld) override;

private:
	ANDisplayEventManager* EventManager = nullptr;
};
