﻿// Copyright Ye RongZhen(MapleLeaf_Ye) 2024


#include "NDisplayEventManager.h"
#include "Cluster/DisplayClusterClusterEvent.h"
#include "IDisplayCluster.h"
#include "JsonObjectConverter.h"
#include "Engine/Classes/Engine/Scene.h"
#include "IPAddress.h"
#include "Serialization/ObjectAndNameAsStringProxyArchive.h"

DEFINE_LOG_CATEGORY_CLASS(ANDisplayEventManager, NDisplayEventManagerLog);


void ANDisplayEventManager::BeginPlay()
{
	Super::BeginPlay();

	//监听多节点事件	

#if VERSION_BINARY
	FunParamPackager = NewObject<UMultiNodeFunParamPackager>();
	check(FunParamPackager);
	EventListener_Binary = FOnClusterEventBinaryListener::CreateUObject(this, &ANDisplayEventManager::OnClusterEventBinaryHandler);
	IDisplayCluster::Get().GetClusterMgr()->AddClusterEventBinaryListener(EventListener_Binary);

#endif // VERSION_BINARY

#if VERSION_JSON

	EventListener = FOnClusterEventJsonListener::CreateUObject(this, &ANDisplayEventManager::OnClusterEventJsonHandler);
	IDisplayCluster::Get().GetClusterMgr()->AddClusterEventJsonListener(EventListener);

#endif // VERSION_JSON

	//EventTest.BindUObject(this, &ANDisplayEventManager::OnClusterEventBinaryHandler);

	UE_LOG(NDisplayEventManagerLog, Display, TEXT("NDisplayEventManager initial over."));
}

void ANDisplayEventManager::TriggleMultiNodeEvent(UObject* FunOwner, FName FunName, TMap<FString, FString>FunParams, EExePath& Path)
{
#if VERSION_JSON
	if (FunName.IsNone())
	{
		UE_LOG(NDisplayEventManagerLog, Warning, TEXT("%s--%d--------%s TriggleMultiNodeEvent FunName is None!!!!"), __FILE__, __LINE__, __FUNCTION__);
		ensureMsgf(0, TEXT("%s--%d--------%s TriggleMultiNodeEvent FunName is None!!!!"), __FILE__, __LINE__, __FUNCTION__);
		return;
	}

	if (!IDisplayCluster::Get().GetClusterMgr()->IsPrimary())
	{
		Path = EExePath::NormalExe;
		return;
	}
	FString ExeId = FunOwner->GetName() + TEXT("_") + FunName.ToString();
	FName ExeIdN = FName(ExeId);
	if (FunExeFlag.Contains(ExeIdN) && FunExeFlag.FindChecked(ExeIdN) == true)
	{
		Path = EExePath::NormalExe;
		return;
	}

	FunExeFlag.Add(ExeIdN, true);
	FDisplayClusterClusterEventJson FunInfo;
	TSoftObjectPtr<UObject*> Tsop(FunOwner);
	FString ObjectPath = Tsop.ToString();
	ObjectPath = ObjectPath.Replace(*FString(":"), *FString("-+-"));
	FunInfo.Category = ObjectPath;
	FunInfo.Name = FunName.ToString();
	FunInfo.Parameters = FunParams;
	Path = EExePath::MultiNodeExe;
	IDisplayCluster::Get().GetClusterMgr()->EmitClusterEventJson(FunInfo, false);
	UE_LOG(NDisplayEventManagerLog, Display, TEXT("Now send multi event:%s..."), *FunName.ToString());
#endif
}

void ANDisplayEventManager::OnClusterEventJsonHandler(const FDisplayClusterClusterEventJson& Event)
{
#if VERSION_JSON
	//过滤第一次绑定执行
	if (!IsBoundEvent)
	{
		IsBoundEvent = true;
		return;
	}
	UE_LOG(NDisplayEventManagerLog, Display, TEXT("Node:%s receiving event:%s."), *IDisplayCluster::Get().GetClusterMgr()->GetNodeId(),*Event.Name);
	//通过对象路径还原对象
	FString ObjectPath = Event.Category;
	ObjectPath = ObjectPath.Replace(*FString("-+-"), *FString(":"));
	FSoftObjectPath SOP(ObjectPath);
	UObject* FunOwner = SOP.ResolveObject();
	//检测有效性

	if (!FunOwner)
	{
		return;
	}
	//得到目标执行函数
	UFunction* TargetFun = FunOwner->FindFunctionChecked(*Event.Name);
	if (!TargetFun)
	{
		return;
	}
	//开辟函数参数空间
	void* FunParamAddr = (uint8*)FMemory_Alloca(TargetFun->ParmsSize);
	FMemory::Memzero(FunParamAddr,TargetFun->ParmsSize);
	int i = 0;
	TArray<FString> ParamKeys;
	Event.Parameters.GetKeys(ParamKeys);
	//遍历函数参数并赋值
	for (TFieldIterator<FProperty> It(TargetFun); It; ++It)
	{
		FProperty* CurrPro = *It;
		if ((CurrPro->PropertyFlags & CPF_Parm) == CPF_Parm && (CurrPro->PropertyFlags & CPF_ReturnParm) == 0 && (CurrPro->PropertyFlags & CPF_OutParm) == 0)
		{
			FString ParamType = CurrPro->GetCPPType();
			FString CurrValue = Event.Parameters.FindChecked(ParamKeys[i]);
			if (ParamType == TEXT("bool"))
			{
				*CurrPro->ContainerPtrToValuePtr<bool>(FunParamAddr) = CurrValue.ToBool();
			}
			else if (ParamType == TEXT("uint8"))
			{
				*CurrPro->ContainerPtrToValuePtr<uint8>(FunParamAddr) = FCString::Atoi(*CurrValue);
			}
			else if (ParamType == TEXT("int32"))
			{
				*CurrPro->ContainerPtrToValuePtr<int32>(FunParamAddr) = FCString::Atoi(*CurrValue);
			}
			else if (ParamType == TEXT("int64"))
			{
				*CurrPro->ContainerPtrToValuePtr<int64>(FunParamAddr) = FCString::Atoi64(*CurrValue);
			}
			else if (ParamType == TEXT("float"))
			{
				*CurrPro->ContainerPtrToValuePtr<float>(FunParamAddr) = FCString::Atof(*CurrValue);
			}
			else if (ParamType == TEXT("double"))
			{
				*CurrPro->ContainerPtrToValuePtr<double>(FunParamAddr) = FCString::Atod(*CurrValue);
			}
#if COMPLETEVERSION
			else if (ParamType == TEXT("FName"))
			{
				*CurrPro->ContainerPtrToValuePtr<FName>(FunParamAddr) = *CurrValue;
			}
			else if (ParamType == TEXT("FString"))
			{
				*CurrPro->ContainerPtrToValuePtr<FString>(FunParamAddr) = CurrValue;
			}
			else if (ParamType == TEXT("FText"))
			{
				*CurrPro->ContainerPtrToValuePtr<FText>(FunParamAddr) = FText::FromString(CurrValue);
			}
#endif // COMPLETEVERSION
			else if (ParamType == TEXT("FVector"))
			{
				CurrPro->ContainerPtrToValuePtr<FVector>(FunParamAddr)->InitFromString(CurrValue);
			}
#if COMPLETEVERSION
			else if (ParamType == TEXT("FRotator"))
			{
				CurrPro->ContainerPtrToValuePtr<FRotator>(FunParamAddr)->InitFromString(CurrValue);
			}
			else if (ParamType == TEXT("FTransform"))
			{
				CurrPro->ContainerPtrToValuePtr<FTransform>(FunParamAddr)->InitFromString(CurrValue);
			}
			else if (ParamType == TEXT("AActor*") || ParamType.Left(1) == TEXT("A"))
			{
				CurrValue = CurrValue.Replace(*FString("-+-"), *FString(":"));
				FSoftObjectPath ASOP(CurrValue);
				AActor* outActor = Cast<AActor>(ASOP.ResolveObject());
				//UE_LOG(NDisplayEventManagerLog, Warning, TEXT("%s--%d--------%s Actor is not valid!!!!"), __FILE__, __LINE__, __FUNCTION__);
				checkf(outActor,TEXT("%s--%d--------%s Actor is not valid!!!!"),__FILE__,__LINE__,__FUNCTION__);
				*CurrPro->ContainerPtrToValuePtr<AActor*>(FunParamAddr) = outActor;
				//GEngine->AddOnScreenDebugMessage(-1, 30.f, FColor::Red, FString::Printf(TEXT("Current path %s --- Object:%s"), *CurrValue, *outActor->GetName()));
			}
			else if (ParamType == TEXT("UObject*") || ParamType.Left(1) == TEXT("U"))
			{
				CurrValue = CurrValue.Replace(*FString("-+-"), *FString(":"));
				FSoftObjectPath USOP(CurrValue);
				UObject* outObject = USOP.ResolveObject();
				//UE_LOG(NDisplayEventManagerLog, Warning, TEXT("%s--%d--------%s Object is not valid!!!!"), __FILE__, __LINE__, __FUNCTION__);
				checkf(outObject,TEXT("%s--%d--------%s Object is not valid!!!!"),__FILE__,__LINE__,__FUNCTION__);
				*CurrPro->ContainerPtrToValuePtr<UObject*>(FunParamAddr) = outObject;
			}
			else if (ParamType == TEXT("FGuid"))
			{
				FGuid tempGuid;
				FGuid::Parse(CurrValue, tempGuid);
				*CurrPro->ContainerPtrToValuePtr<FGuid>(FunParamAddr) = tempGuid;
			}
#endif // COMPLETEVERSION
			else
			{
#if COMPLETEVERSION
				CurrPro->ImportText_InContainer(CurrValue.GetCharArray().GetData(), FunParamAddr, nullptr, PPF_None);
#else
				UE_LOG(NDisplayEventManagerLog, Error, TEXT("Current Type : %s is not supported in the trial version!!!"), *ParamType);
				UE_LOG(NDisplayEventManagerLog, Error, CHECKEDCOMPLETEVERSIONMESSAGE);
				checkf(0, CHECKEDCOMPLETEVERSIONMESSAGE);
				return;
#endif // COMPLETEVERSION
			}
			i++;
		}
	}
	//执行函数
	FunOwner->ProcessEvent(TargetFun,FunParamAddr);
	CallNdisplayEventOver(FunOwner, *Event.Name);
	UE_LOG(NDisplayEventManagerLog, Display, TEXT("Node:%s received event:%s over."), *IDisplayCluster::Get().GetClusterMgr()->GetNodeId(), *Event.Name);
#endif
}

void ANDisplayEventManager::TriggleMultiNodeEvent_Binary(UObject* FunOwner, FName FunName, TArray<FMultiNodeFunParam>& FunParams, EExePath& Path)
{
#if VERSION_BINARY && COMPLETEVERSION
	if (FunName.IsNone())
	{
		UE_LOG(NDisplayEventManagerLog, Warning, TEXT("%s--%d--------%s TriggleMultiNodeEvent FunName is None!!!!"), __FILE__, __LINE__, __FUNCTION__);
		ensureMsgf(0, TEXT("%s--%d--------%s TriggleMultiNodeEvent FunName is None!!!!"), __FILE__, __LINE__, __FUNCTION__);
		return;
	}

	if (!IDisplayCluster::Get().GetClusterMgr()->IsPrimary())
	{
		Path = EExePath::NormalExe;
		return;
	}
	FString ExeId = FunOwner->GetName() + TEXT("_") + FunName.ToString();
	FName ExeIdN = FName(ExeId);
	if (FunExeFlag.Contains(ExeIdN) && FunExeFlag.FindChecked(ExeIdN) == true)
	{
		Path = EExePath::NormalExe;
		return;
	}
	GetFunParamPackager()->ClearPackagerParams();
	FunExeFlag.Add(ExeIdN, true);
	FDisplayClusterClusterEventBinary FunInfo;
	TSoftObjectPtr<UObject*> Tsop(FunOwner);
	FString ObjectPath = Tsop.ToString();
	ObjectPath = ObjectPath.Replace(*FString(":"), *FString("-+-"));
	GetFunParamPackager()->SetIsCPP(false);
	GetFunParamPackager()->AssignNewFunParams(FunParams);
	GetFunParamPackager()->SetFuncOwnerAndFuncName(ObjectPath, FunName.ToString());
	FMemoryWriter memoryWriter(FunInfo.EventData, true);
	FObjectAndNameAsStringProxyArchive Ar(memoryWriter, false);
	Ar.ArIsSaveGame = true;
	Ar.ArNoDelta = true;
	GetFunParamPackager()->Serialize(Ar);
	Path = EExePath::MultiNodeExe;
	IDisplayCluster::Get().GetClusterMgr()->EmitClusterEventBinary(FunInfo, false);
	UE_LOG(NDisplayEventManagerLog, Display, TEXT("Now send multi event:%s..."), &FunName);
#endif
}

void ANDisplayEventManager::OnClusterEventBinaryHandler(const FDisplayClusterClusterEventBinary& Event)
{
#if VERSION_BINARY && COMPLETEVERSION
	GetFunParamPackager()->ClearPackagerParams();
	FMemoryReader memoryReader(Event.EventData, true);
	FObjectAndNameAsStringProxyArchive Ar(memoryReader, false);
	Ar.ArIsSaveGame = true;
	Ar.ArNoDelta = true;
	GetFunParamPackager()->Serialize(Ar);
	if (GetFunParamPackager()->GetIsCPPEvent())
	{
		return;
	}
	FName funName = *GetFunParamPackager()->GetFunName();
	UE_LOG(NDisplayEventManagerLog, Display, TEXT("Node:%s receiving event:%s."), *IDisplayCluster::Get().GetClusterMgr()->GetNodeId(), &funName);

	//通过对象路径还原对象
	const FString ObjectPath = GetFunParamPackager()->GetFunOwner().Replace(*FString("-+-"), *FString(":"));
	FSoftObjectPath SOP(ObjectPath);
	UObject* FunOwner = SOP.ResolveObject();
	//检测有效性
	if (!FunOwner)
	{
		return;
	}
	//得到目标执行函数
	UFunction* TargetFun = FunOwner->FindFunctionChecked(funName);
	if (!TargetFun)
	{
		return;
	}
	//开辟函数参数空间
	void* FunParamAddr = (uint8*)FMemory_Alloca(TargetFun->ParmsSize);
	FMemory::Memzero(FunParamAddr, TargetFun->ParmsSize);
	int32 i = 0;
	//遍历函数参数并赋值
	for (TFieldIterator<FProperty> It(TargetFun); It; ++It)
	{
		FProperty* CurrPro = *It;
		if ((CurrPro->PropertyFlags & CPF_Parm) == CPF_Parm && (CurrPro->PropertyFlags & CPF_ReturnParm) == 0 && (CurrPro->PropertyFlags & CPF_OutParm) == 0)
		{
			FString ParamType = CurrPro->GetCPPType();
			if (ParamType == TEXT("UObject*") || ParamType.Left(1) == TEXT("U"))
			{
				FMultiNodeFunParam& param = GetFunParamPackager()->GetPackagedParam(i);
				if (param.bIsValid && param.bIsUObject)
				{
					static FString CurrStr = param.UObjectSoftPath.Replace(*FString("-+-"), *FString(":"));
					FSoftObjectPath USOP(CurrStr);
					UObject* outObject = USOP.ResolveObject();
					if (!outObject)
					{
						UE_LOG(NDisplayEventManagerLog, Warning, TEXT("%s--%d--------%s Object is not valid!!!!"), __FILE__, __LINE__, __FUNCTION__);
					}
					checkf(outObject, TEXT("%s--%d--------%s Object is not valid!!!!"), __FILE__, __LINE__, __FUNCTION__);
					*CurrPro->ContainerPtrToValuePtr<UObject*>(FunParamAddr) = outObject;
				}
				else
				{
					check(0);
				}
			}
			else if (ParamType == TEXT("AActor*") || ParamType.Left(1) == TEXT("A"))
			{
				FMultiNodeFunParam& param = GetFunParamPackager()->GetPackagedParam(i);
				if (param.bIsValid && param.bIsUObject)
				{
					static FString CurrStr = param.UObjectSoftPath.Replace(*FString("-+-"), *FString(":"));
					FSoftObjectPath ASOP(CurrStr);
					AActor* outActor = Cast<AActor>(ASOP.ResolveObject());
					if (!outActor)
					{
						UE_LOG(NDisplayEventManagerLog, Warning, TEXT("%s--%d--------%s Actor is not valid!!!!"), __FILE__, __LINE__, __FUNCTION__);
					}
					checkf(outActor, TEXT("%s--%d--------%s Actor is not valid!!!!"), __FILE__, __LINE__, __FUNCTION__);
					*CurrPro->ContainerPtrToValuePtr<UObject*>(FunParamAddr) = outActor;
				}
				else
				{
					check(0);
				}
			}
			else
			{
				FMultiNodeFunParam& param = GetFunParamPackager()->GetPackagedParam(i);
				if (param.bIsValid && !param.bIsUObject)
				{
					void* CurParamAddr = CurrPro->ContainerPtrToValuePtr<void*>(FunParamAddr);
					CurrPro->CopyCompleteValue(CurParamAddr, param.FunParamData.GetData());
				}
				else
				{
					check(0);
				}
			}
			i++;
		}
	}
	//执行函数
	FunOwner->ProcessEvent(TargetFun, FunParamAddr);
	CallNdisplayEventOver(FunOwner, funName);
	GetFunParamPackager()->ClearPackagerParams();
	UE_LOG(NDisplayEventManagerLog, Display, TEXT("Node:%s received event:%s over."), *IDisplayCluster::Get().GetClusterMgr()->GetNodeId(), &funName);
#endif
}

void ANDisplayEventManager::CallNdisplayEventOver(UObject* FunOwner,FName FunName)
{
	if (!IDisplayCluster::Get().GetClusterMgr()->IsPrimary())
	{
		return;
	}
	FString ExeId = FunOwner->GetName() + TEXT("_") + FunName.ToString();
	FName ExeIdN = FName(ExeId);
	if (FunExeFlag.Contains(ExeIdN) && FunExeFlag.FindChecked(ExeIdN) == true)
	{
		FunExeFlag.Remove(ExeIdN);
	}
	UE_LOG(NDisplayEventManagerLog, Display, TEXT("event:%s over."), *FunName.ToString());
}

UMultiNodeFunParamPackager*& ANDisplayEventManager::GetFunParamPackager()
{
	if (FunParamPackager)
	{
		return FunParamPackager;
	}
	else
	{
		FunParamPackager = NewObject<UMultiNodeFunParamPackager>();
		check(FunParamPackager);
		return FunParamPackager;
	}
}

void ANDisplayEventManager::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);
	IDisplayCluster::Get().GetClusterMgr()->RemoveClusterEventJsonListener(EventListener);
	UE_LOG(NDisplayEventManagerLog, Display, TEXT("NDisplayEventManage close..."));
}
