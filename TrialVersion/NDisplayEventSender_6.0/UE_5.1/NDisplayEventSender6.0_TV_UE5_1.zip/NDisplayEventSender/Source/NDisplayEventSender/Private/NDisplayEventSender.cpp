﻿// Copyright Ye RongZhen(MapleLeaf_Ye) 2024


#include "NDisplayEventSender.h"

//#if WITH_EDITOR
//#include "Editor.h"
//#include "FileHelpers.h"
//#include "LevelEditor.h"
//#include "Misc/MessageDialog.h"
//#endif

#include "NDisplayEventManager.h"
#include "Kismet/GameplayStatics.h"

#define LOCTEXT_NAMESPACE "FNDisplayEventSenderModule"


void FNDisplayEventSenderModule::StartupModule()
{
}

void FNDisplayEventSenderModule::ShutdownModule()
{
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FNDisplayEventSenderModule, NDisplayEventSender)