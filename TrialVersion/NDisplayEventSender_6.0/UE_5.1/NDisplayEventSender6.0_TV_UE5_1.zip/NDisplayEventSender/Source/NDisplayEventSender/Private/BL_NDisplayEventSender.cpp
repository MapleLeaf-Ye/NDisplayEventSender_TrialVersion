﻿// Copyright Ye RongZhen(MapleLeaf_Ye) 2024


#include "BL_NDisplayEventSender.h"
#include "Kismet/GameplayStatics.h"
#include "Kismet/KismetStringLibrary.h"
#include "NDisplayEventSubsystem.h"
#include "Engine/Classes/Engine/World.h"
#include "Engine/Classes/Engine/Engine.h"

DEFINE_LOG_CATEGORY_CLASS(UBL_NDisplayEventSender,BL_NDisplayEventSenderLog)

DEFINE_FUNCTION(UBL_NDisplayEventSender::execInputParamToString)
{
	P_GET_OBJECT(UObject, Z_Param_WorldContextObject);
	Stack.StepCompiledIn<FProperty>(NULL);
	void* SrcPropertyAddr = Stack.MostRecentPropertyAddress;
	FProperty* SrcProperty = Stack.MostRecentProperty;
	P_FINISH;
	P_NATIVE_BEGIN;
	*(FString*)Z_Param__Result = UBL_NDisplayEventSender::InputParamToString_Native(Z_Param_WorldContextObject, SrcProperty, SrcPropertyAddr);
	P_NATIVE_END;
}

FString UBL_NDisplayEventSender::InputParamToString_Native(const UObject* WorldContextObject, const FProperty* InPro,
	void* ProAddress)
{
	FString ParamType = InPro->GetCPPType();
	
	FString outValue = FString();
	if (ParamType == TEXT("bool"))
	{
		const FBoolProperty* p = CastFieldChecked<FBoolProperty>(InPro);
		const bool v = p->GetPropertyValue(ProAddress);
		outValue = UKismetStringLibrary::Conv_BoolToString(v);
		return outValue;
	}
	else if (ParamType == TEXT("uint8"))
	{
		const FByteProperty* p = CastFieldChecked<FByteProperty>(InPro);
		const uint8 v = p->GetPropertyValue(ProAddress);
		outValue = UKismetStringLibrary::Conv_ByteToString(v);
		return outValue;
	}
	else if (ParamType == TEXT("int32"))
	{
		const FIntProperty* p = CastFieldChecked<FIntProperty>(InPro);
		const int32 v = p->GetPropertyValue(ProAddress);
		outValue = UKismetStringLibrary::Conv_IntToString(v);
		return outValue;
	}
	else if (ParamType == TEXT("int64"))
	{
		const FInt64Property* p = CastFieldChecked<FInt64Property>(InPro);
		const int64 v = p->GetPropertyValue(ProAddress);
		outValue = UKismetStringLibrary::Conv_Int64ToString(v);
		return outValue;
	}
	else if (ParamType == TEXT("float"))
	{
		const FFloatProperty* p = CastFieldChecked<FFloatProperty>(InPro);
		const float v = p->GetPropertyValue(ProAddress);
		outValue = FString::SanitizeFloat(v);
		return outValue;
	}
	else if (ParamType == TEXT("double"))
	{
		const FDoubleProperty* p = CastFieldChecked<FDoubleProperty>(InPro);
		const double v = p->GetPropertyValue(ProAddress);
		outValue = FString::SanitizeFloat(v);
		return outValue;
	}
#if COMPLETEVERSION
	else if (ParamType == TEXT("FName"))
	{
		const FNameProperty* p = CastFieldChecked<FNameProperty>(InPro);
		const FName v = p->GetPropertyValue(ProAddress);
		outValue = v.ToString();
		return outValue;
	}
	else if (ParamType == TEXT("FString"))
	{
		const FStrProperty* p = CastFieldChecked<FStrProperty>(InPro);
		const FString v = p->GetPropertyValue(ProAddress);
		outValue = v;
		return outValue;
	}
	else if (ParamType == TEXT("FText"))
	{
		const FTextProperty* p = CastFieldChecked<FTextProperty>(InPro);
		const FText v = p->GetPropertyValue(ProAddress);
		outValue = v.ToString();
		return outValue;
	}
#endif // COMPLETEVERSION
	else if (ParamType == TEXT("FVector"))
	{
		const FVector* v = (FVector const*)ProAddress;
		outValue = UKismetStringLibrary::Conv_VectorToString(*v);
		return outValue;
	}
#if COMPLETEVERSION
	else if (ParamType == TEXT("FRotator"))
	{
		const FRotator* v = (const FRotator*)ProAddress;
		outValue = UKismetStringLibrary::Conv_RotatorToString(*v);
		return outValue;
	}
	else if (ParamType == TEXT("FTransform"))
	{
		const FTransform* v = (const FTransform*)ProAddress;
		outValue = UKismetStringLibrary::Conv_TransformToString(*v);
		return outValue;
	}
	else if (ParamType == TEXT("AActor*") || ParamType.Left(1) == TEXT("A"))
	{
		const FObjectProperty* p = CastFieldChecked<FObjectProperty>(InPro);
		const TObjectPtr<UObject> v = p->GetPropertyValue(ProAddress);

		K2_ObjectToNDisEventString(v, outValue);
		return outValue;
	}
	else if (ParamType == TEXT("UObject*") || ParamType.Left(1) == TEXT("U"))
	{
		const FObjectProperty* p = CastFieldChecked<FObjectProperty>(InPro);
		const TObjectPtr<UObject> v = p->GetPropertyValue(ProAddress);

		K2_ObjectToNDisEventString(v, outValue);
		return outValue;
	}
	else if (ParamType == TEXT("FGuid"))
	{
		const FGuid* v = (const FGuid*)ProAddress;
		outValue = *v->ToString();
		return outValue;
	}
#endif // COMPLETEVERSION
	else
	{
#if COMPLETEVERSION
		InPro->ExportText_Direct(outValue, ProAddress, ProAddress, nullptr, PPF_None);
		return outValue;
#else
		UE_LOG(BL_NDisplayEventSenderLog, Error, TEXT("Current Type : %s is not supported in the trial version!!!"), *ParamType);
		UE_LOG(BL_NDisplayEventSenderLog, Error, CHECKEDCOMPLETEVERSIONMESSAGE);
		checkf(0, CHECKEDCOMPLETEVERSIONMESSAGE);
		return FString();
#endif // COMPLETEVERSION
	}
	return outValue;
}

DEFINE_FUNCTION(UBL_NDisplayEventSender::execInputParamToMultiNodeFunParam)
{
	P_GET_OBJECT(UObject, Z_Param_WorldContextObject);
	Stack.StepCompiledIn<FProperty>(NULL);
	void* SrcPropertyAddr = Stack.MostRecentPropertyAddress;
	FProperty* SrcProperty = Stack.MostRecentProperty;
	P_FINISH;
	P_NATIVE_BEGIN;
	*(FMultiNodeFunParam*)Z_Param__Result = UBL_NDisplayEventSender::InputParamToMultiNodeFunParam_Native(Z_Param_WorldContextObject, SrcProperty, SrcPropertyAddr);
	P_NATIVE_END;
}

FMultiNodeFunParam UBL_NDisplayEventSender::InputParamToMultiNodeFunParam_Native(const UObject* WorldContextObject, const FProperty* InPro, void* ProAddress)
{
#if COMPLETEVERSION
	FString ParamType = InPro->GetCPPType();
	if (ParamType == TEXT("UObject*") || ParamType.Left(1) == TEXT("U"))
	{
		const FObjectProperty* p = CastFieldChecked<FObjectProperty>(InPro);
		const TObjectPtr<UObject> v = p->GetPropertyValue(ProAddress);
		FString s;
		K2_ObjectToNDisEventString(v, s);
		return FMultiNodeFunParam(true,s,TArray<uint8>());
	}
	else if (ParamType == TEXT("AActor*") || ParamType.Left(1) == TEXT("A"))
	{
		const FObjectProperty* p = CastFieldChecked<FObjectProperty>(InPro);
		const TObjectPtr<UObject> v = p->GetPropertyValue(ProAddress);
		FString s;
		K2_ObjectToNDisEventString(v, s);
		return FMultiNodeFunParam(true, s, TArray<uint8>());
	}
	else
	{
		TArray<uint8> outDatas;
		
		outDatas.AddUninitialized(InPro->ElementSize * InPro->ArrayDim);
		//FMemory::Memcpy(outDatas.GetData(), ProAddress, outDatas.Num());
		InPro->CopyCompleteValue(outDatas.GetData(), ProAddress);
		return FMultiNodeFunParam(false, FString(), outDatas);
	}
#else
	UE_LOG(BL_NDisplayEventSenderLog, Error, CHECKEDCOMPLETEVERSIONMESSAGE);
	checkf(0, CHECKEDCOMPLETEVERSIONMESSAGE);
	return FMultiNodeFunParam();
#endif // COMPLETEVERSION
}

DEFINE_FUNCTION(UBL_NDisplayEventSender::execK2_TriggleMultiNodeEvent_Simple)
{
	FName funName = TEXT("ErrorCallFunc_Native");
	P_GET_OBJECT(UObject, Z_Param_WorldContextObject);
	P_GET_TARRAY_REF(FString, Z_Param_Out_FunParams);
	P_GET_ENUM_REF(EExePath, Z_Param_Out_ExePath);
	P_FINISH;
	if (Stack.PreviousFrame &&
		Stack.PreviousFrame->CurrentNativeFunction &&
		Stack.PreviousFrame->CurrentNativeFunction->HasAnyFunctionFlags(FUNC_BlueprintCallable | FUNC_BlueprintEvent)
		)
	{
		funName = *Stack.PreviousFrame->CurrentNativeFunction->GetName();
	}
	else if (Stack.PreviousFrame &&
		Stack.PreviousFrame->Node &&
		Stack.PreviousFrame->Node->HasAnyFunctionFlags(FUNC_BlueprintCallable | FUNC_BlueprintEvent))
	{
		funName = *Stack.PreviousFrame->Node->GetName();
	}
	else if (*Stack.Node->GetName())
	{
		funName = *Stack.Node->GetName();
	}
	else
	{
		P_NATIVE_BEGIN;
		UBL_NDisplayEventSender::ErrorCallFunc_Native();
		P_NATIVE_END;
		return;
	}
	P_NATIVE_BEGIN;
	UBL_NDisplayEventSender::TriggleMultiNodeEvent_Simple_Native(Z_Param_WorldContextObject, Stack.Object, funName, Z_Param_Out_FunParams, (EExePath&)(Z_Param_Out_ExePath));
	P_NATIVE_END;
}

void UBL_NDisplayEventSender::TriggleMultiNodeEvent_Simple_Native(const UObject* WorldContextObject, UObject* FunOwner,
	FName FunName,  const TArray<FString>& FunParams, EExePath& ExePath)
{
	if (FunName.IsNone())
	{
		UE_LOG(BL_NDisplayEventSenderLog, Warning, TEXT("%s--%d--------%s ExecuteMultiNodeEvent FunName is None!!!!"), __FILE__, __LINE__, __FUNCTION__);
		ensureMsgf(0, TEXT("%s--%d--------%s ExecuteMultiNodeEvent FunName is None!!!!"), __FILE__, __LINE__, __FUNCTION__);
		return;
	}
	
	ANDisplayEventManager* EventManager = WorldContextObject->GetWorld()->GetSubsystem<UNDisplayEventSubsystem>()->GetMultiEventManager();
	if (!EventManager)
	{
		UE_LOG(BL_NDisplayEventSenderLog, Warning, TEXT("%s--%d--------%s Scene dont have EventManager!!!!"), __FILE__, __LINE__, __FUNCTION__);
		return;
	}
		
	checkf(EventManager, TEXT("%s--%d--------%s ANDisplayEventManager is not valid!!!!"), __FILE__, __LINE__, __FUNCTION__);
	TMap<FString,FString> InFunParams;
	int i = 0;
	for (FString current : FunParams)
	{
		FString currentKey = FString::Printf(TEXT("Param_%d"),i);
		InFunParams.Add(currentKey,current);
		i++;
	}
	EventManager->TriggleMultiNodeEvent(FunOwner, FunName, InFunParams, ExePath);
}

DEFINE_FUNCTION(UBL_NDisplayEventSender::execK2_TriggleMultiNodeEvent_Binary_Simple)
{
	FName funName = TEXT("ErrorCallFunc_Native");
	P_GET_OBJECT(UObject, Z_Param_WorldContextObject);
	P_GET_TARRAY_REF(FMultiNodeFunParam, Z_Param_Out_FunParams);
	P_GET_ENUM_REF(EExePath, Z_Param_Out_ExePath);
	P_FINISH;
	if (Stack.PreviousFrame &&
		Stack.PreviousFrame->CurrentNativeFunction &&
		Stack.PreviousFrame->CurrentNativeFunction->HasAnyFunctionFlags(FUNC_BlueprintCallable | FUNC_BlueprintEvent)
		)
	{
		funName = *Stack.PreviousFrame->CurrentNativeFunction->GetName();
	}
	else if (Stack.PreviousFrame &&
		Stack.PreviousFrame->Node &&
		Stack.PreviousFrame->Node->HasAnyFunctionFlags(FUNC_BlueprintCallable | FUNC_BlueprintEvent))
	{
		funName = *Stack.PreviousFrame->Node->GetName();
	}
	else if (*Stack.Node->GetName())
	{
		funName = *Stack.Node->GetName();
	}
	else
	{
		P_NATIVE_BEGIN;
		UBL_NDisplayEventSender::ErrorCallFunc_Native();
		P_NATIVE_END;
		return;
	}
	P_NATIVE_BEGIN;
	UBL_NDisplayEventSender::TriggleMultiNodeEvent_Simple_Binary_Native(Z_Param_WorldContextObject, Stack.Object, funName, Z_Param_Out_FunParams, (EExePath&)(Z_Param_Out_ExePath));
	P_NATIVE_END;
}

void UBL_NDisplayEventSender::TriggleMultiNodeEvent_Simple_Binary_Native(const UObject* WorldContextObject, UObject* FunOwner, FName FunName, TArray<FMultiNodeFunParam>& FunParams, EExePath& ExePath)
{
	if (FunName.IsNone())
	{
		UE_LOG(BL_NDisplayEventSenderLog, Warning, TEXT("%s--%d--------%s ExecuteMultiNodeEvent FunName is None!!!!"), __FILE__, __LINE__, __FUNCTION__);
		ensureMsgf(0, TEXT("%s--%d--------%s ExecuteMultiNodeEvent FunName is None!!!!"), __FILE__, __LINE__, __FUNCTION__);
		return;
	}

	ANDisplayEventManager* EventManager = WorldContextObject->GetWorld()->GetSubsystem<UNDisplayEventSubsystem>()->GetMultiEventManager();
	if (!EventManager)
	{
		UE_LOG(BL_NDisplayEventSenderLog, Warning, TEXT("%s--%d--------%s Scene dont have EventManager!!!!"), __FILE__, __LINE__, __FUNCTION__);
		return;
	}

	checkf(EventManager, TEXT("%s--%d--------%s ANDisplayEventManager is not valid!!!!"), __FILE__, __LINE__, __FUNCTION__);
	EventManager->TriggleMultiNodeEvent_Binary(FunOwner, FunName, FunParams, ExePath);
}

void UBL_NDisplayEventSender::K2_ObjectToNDisEventString(const UObject* InObject, FString& OutObjectString)
{
#if COMPLETEVERSION
	OutObjectString = FSoftObjectPath(InObject).ToString();
	OutObjectString = OutObjectString.Replace(*FString(":"), *FString("-+-"));
#else
	UE_LOG(BL_NDisplayEventSenderLog, Error, TEXT("Current Type : UObject is not supported in the trial version!!!"));
	UE_LOG(BL_NDisplayEventSenderLog, Error, CHECKEDCOMPLETEVERSIONMESSAGE);
	checkf(0, CHECKEDCOMPLETEVERSIONMESSAGE);
	return;
#endif // COMPLETEVERSION
}

void UBL_NDisplayEventSender::K2_ActorToNDisEventString(const AActor* InActor, FString& OutActorString)
{
#if COMPLETEVERSION
	OutActorString = FSoftObjectPath(InActor).ToString();
	OutActorString = OutActorString.Replace(*FString(":"), *FString("-+-"));
#else
	UE_LOG(BL_NDisplayEventSenderLog, Error, TEXT("Current Type : AActor is not supported in the trial version!!!"));
	UE_LOG(BL_NDisplayEventSenderLog, Error, CHECKEDCOMPLETEVERSIONMESSAGE);
	checkf(0, CHECKEDCOMPLETEVERSIONMESSAGE);
	return;
#endif // COMPLETEVERSION
}

void UBL_NDisplayEventSender::ErrorCallFunc_Native()
{
	GEngine->AddOnScreenDebugMessage(-1, 10.f, FColor::Red, FString::Printf(TEXT("%s--%d--------%s ExecuteMultiNodeEvent Execute Func Fail!!!! Please Check the Node,You Must Placed The ExecuteMultiNodeEvent Node after a function or custom event First"), __FILE__, __LINE__, __FUNCTION__));
	UE_LOG(BL_NDisplayEventSenderLog, Warning, TEXT("%s--%d--------%s ExecuteMultiNodeEvent Execute Func Fail!!!! Please Check the Node,You Must Placed The ExecuteMultiNodeEvent Node after a function or custom event First"), __FILE__, __LINE__, __FUNCTION__);
	ensureMsgf(0, TEXT("%s--%d--------%s ExecuteMultiNodeEvent Execute Func Fail!!!! Please Check the Node,You Must Placed The ExecuteMultiNodeEvent Node after a function or custom event First"), __FILE__, __LINE__, __FUNCTION__);
	return;
}

void UBL_NDisplayEventSender::TriggleMultiNodeEvent_CPP_Native(UObject* FunOwner, const FName FunName, EExePath& ExePath, const uint8*& InParamAddress)
{
#if COMPLETEVERSION
	if (FunName.IsNone())
	{
		UE_LOG(BL_NDisplayEventSenderLog, Warning, TEXT("%s--%d--------%s ExecuteMultiNodeEvent FunName is None!!!!"), __FILE__, __LINE__, __FUNCTION__);
		ensureMsgf(0, TEXT("%s--%d--------%s ExecuteMultiNodeEvent FunName is None!!!!"), __FILE__, __LINE__, __FUNCTION__);
		return;
	}

	ANDisplayEventManager* EventManager = Cast<ANDisplayEventManager>(UGameplayStatics::GetActorOfClass(FunOwner->GetWorld(), ANDisplayEventManager::StaticClass()));
	if (!EventManager)
	{
		UE_LOG(BL_NDisplayEventSenderLog, Warning, TEXT("%s--%d--------%s Scene dont have EventManager!!!!"), __FILE__, __LINE__, __FUNCTION__);
		return;
	}

	checkf(EventManager, TEXT("%s--%d--------%s ANDisplayEventManager is not valid!!!!"), __FILE__, __LINE__, __FUNCTION__);

	UFunction* fun = FunOwner->FindFunctionChecked(FunName);
	TMap<FString, FString> outFunParams;
	int32 i = 0;
	int32 offset = 0;
	for (TFieldIterator<FProperty> It(fun); It; ++It)
	{
		FProperty* CurrPro = *It;
		FString ParamType = CurrPro->GetCPPType();
		if ((CurrPro->PropertyFlags & CPF_Parm) == CPF_Parm && (CurrPro->PropertyFlags & CPF_ReturnParm) == 0 && (CurrPro->PropertyFlags & CPF_OutParm) == 0)
		{
			FString currentStr;
			offset = CurrPro->GetOffset_ForInternal();
			CurrPro->ExportText_Direct(currentStr, InParamAddress + offset, InParamAddress + offset, nullptr, PPF_None);
			if (ParamType == TEXT("UObject*") || ParamType.Left(1) == TEXT("U"))
			{
				currentStr = currentStr.Replace(*FString(":"), *FString("-+-"));
			}
			else if (ParamType == TEXT("AActor*") || ParamType.Left(1) == TEXT("A"))
			{
				currentStr = currentStr.Replace(*FString(":"), *FString("-+-"));
			}
			outFunParams.Add(TTuple<FString, FString>(FString::FromInt(i), currentStr));
			++i;
		}
	}

	EventManager->TriggleMultiNodeEvent(FunOwner, FunName, outFunParams, ExePath);
#else
	UE_LOG(BL_NDisplayEventSenderLog, Error, CHECKEDCOMPLETEVERSIONMESSAGE);
	checkf(0, CHECKEDCOMPLETEVERSIONMESSAGE);
	return;
#endif // COMPLETEVERSION
}


