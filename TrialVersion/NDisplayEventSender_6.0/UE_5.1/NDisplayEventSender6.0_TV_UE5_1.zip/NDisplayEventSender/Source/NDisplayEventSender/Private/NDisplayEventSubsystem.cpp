﻿// Copyright Ye RongZhen(MapleLeaf_Ye) 2024


#include "NDisplayEventSubsystem.h"
#include "NDisplayEventManager.h"
#include "Kismet/GameplayStatics.h"
#include "Engine/Classes/Engine/World.h"

ANDisplayEventManager* UNDisplayEventSubsystem::GetMultiEventManager()
{
	if (EventManager)
	{
		return EventManager;
	}
	else
	{
		EventManager = Cast<ANDisplayEventManager>(UGameplayStatics::GetActorOfClass(GetWorld(), ANDisplayEventManager::StaticClass()));
		if (!EventManager)
		{
			EventManager = GetWorld()->SpawnActor<ANDisplayEventManager>();
		}
		return EventManager;
	}
}

void UNDisplayEventSubsystem::OnWorldBeginPlay(UWorld& InWorld)
{
	//子系统自动创建管理器
	if (InWorld.WorldType == EWorldType::Game || InWorld.WorldType == EWorldType::GamePreview || InWorld.WorldType == EWorldType::GameRPC ||
		InWorld.WorldType == EWorldType::PIE)
	{
		EventManager = Cast<ANDisplayEventManager>(UGameplayStatics::GetActorOfClass(&InWorld, ANDisplayEventManager::StaticClass()));
		if (!EventManager)
		{
			EventManager = InWorld.SpawnActor<ANDisplayEventManager>();
		}
	}
}
